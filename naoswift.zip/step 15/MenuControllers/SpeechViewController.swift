import UIKit
import SwiftSocket
import Speech

class SpeechViewController: UIViewController, SFSpeechRecognizerDelegate, UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
    
    /* Metodi e variabili per la table view */
    var chatMsg = [String]()
    
    var temp: String = " "
    //var temp : String!
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // 1
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //return self.msgSent.count + self.msgRcv.count
        return self.chatMsg.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        /*
         if indexPath.row % 2 == 0 {
         // Sent message
         let cell:SenderTableViewCell = self.chatView.dequeueReusableCell(withIdentifier: "sender", for: indexPath) as! SenderTableViewCell
         print(indexPath.row)
         //cell.texttLabel?.text = self.msgSent[(indexPath.row-msgRcv.count)]
         cell.texttLabel?.text = self.chatMsg[indexPath.row]
         cell.texttLabel?.sizeToFit()
         cell.texttLabel?.numberOfLines = 2
         //self.chatView.scrollToRow(at: indexPath, at: .bottom, animated: true)
         return cell
         } else {
         // Received message
         let rcell:ReceiverTableViewCell = self.chatView.dequeueReusableCell(withIdentifier: "receiver", for: indexPath) as! ReceiverTableViewCell
         print(indexPath.row)
         //rcell.texttLabel?.text = self.msgRcv[indexPath.row-msgSent.count]
         rcell.texttLabel?.text = self.chatMsg[indexPath.row]
         rcell.texttLabel?.sizeToFit()
         rcell.texttLabel?.numberOfLines = 2
         //self.chatView.scrollToRow(at: indexPath, at: .bottom, animated: true)
         return rcell
         }
         */
        if indexPath.row % 2 == 0 {
            let cell:SenderTableViewCell = self.chatView.dequeueReusableCell(withIdentifier: "sender", for: indexPath) as! SenderTableViewCell
            cell.textView.text = self.chatMsg[indexPath.row]
            cell.textView.textColor = .red
            cell.textView.font = UIFont.systemFont(ofSize: 16.0)
            return cell
        } else {
            let cell:ReceiverTableViewCell = self.chatView.dequeueReusableCell(withIdentifier: "receiver", for: indexPath) as! ReceiverTableViewCell
            cell.textView.text = self.chatMsg[indexPath.row]
            cell.textView.textColor = .black
            cell.textView.font = UIFont.systemFont(ofSize: 16.0)
            return cell
        }
    }
    
    
    
    //@IBOutlet weak var textView: UITextView!
    @IBOutlet weak var microphoneButton: UIButton!
    @IBOutlet weak var siriLan : UITextField!
    @IBOutlet weak var chatView: UITableView!
    @IBOutlet weak var siriLabel: UILabel!
    
    var picker: UIPickerView!
    var siriLanAV : [String:String] = ["en-EN" : "English" , "it-IT" : "Italiano", "fr-FR" : "Français", "de-DE" : "Deutsch", "es-ES" : "Español"]
    var speechRL : String = "it-IT"
    var speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: "it-IT"))
    var active : Bool!
    var timer : Timer?
    
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()
    
    var host = ""  // settata dall'utente
    let port = 7783
    var client: TCPClient?
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.host = ipAddress
        client = TCPClient(address: host, port: Int32(port))
        chatView.delegate = self
        chatView.dataSource = self
        
        self.siriLan.text = "Italiano"
        self.speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: self.speechRL))
        
        microphoneButton.isEnabled = false  //2
        
        speechRecognizer!.delegate = self  //3
        
        SFSpeechRecognizer.requestAuthorization { (authStatus) in  //4
            
            var isButtonEnabled = false
            
            switch authStatus {  //5
            case .authorized:
                isButtonEnabled = true
                
            case .denied:
                isButtonEnabled = false
                print("User denied access to speech recognition")
                
            case .restricted:
                isButtonEnabled = false
                print("Speech recognition restricted on this device")
                
            case .notDetermined:
                isButtonEnabled = false
                print("Speech recognition not yet authorized")
            }
            
            OperationQueue.main.addOperation() {
                //self.microphoneButton.isEnabled = isButtonEnabled
            }
        }
        /*
        self.startSpeech()
        timer?.invalidate()
        self.timer = nil
        if self.timer == nil{
            self.timer = Timer.scheduledTimer(timeInterval: 8.0, target: self, selector: #selector(SpeechViewController.startSpeech),userInfo: nil, repeats: true)
            self.active = true
        }*/
        
        hideKeyboardWhenTappedAround()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.chatMsg.removeAll()
        self.chatView.reloadData()
        self.client = TCPClient(address: ipAddress, port: 7783)
        
        // INIZIALIZZO IL DISCORSO CONTINUO
        self.startSpeech()
        timer?.invalidate()
        self.timer = nil
        if self.timer == nil{
            self.timer = Timer.scheduledTimer(timeInterval: 9.0, target: self, selector: #selector(SpeechViewController.startSpeech),userInfo: nil, repeats: true)
            self.active = true
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        timer?.invalidate()
        self.timer = nil
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        NotificationCenter.default.addObserver(forName: .UIContentSizeCategoryDidChange, object: .none, queue: OperationQueue.main) { [weak self] _ in
            self?.chatView.reloadData()
        }
    }
    
    @objc private func startSpeech(){
        if audioEngine.isRunning == false {
            self.startRecording()
            self.microphoneButton.isEnabled = true
            self.microphoneButton.setTitle("In ascolto", for: .normal)
            
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(4), execute: {
                // DOPO 4 SECONDI FERMO IL MOTORE DI SPEECH RECOGNITION
                // Put your code which should be executed with a delay here
                self.audioEngine.stop()
                self.audioEngine.inputNode.removeTap(onBus: 0)
                self.audioEngine.inputNode.reset()
                self.recognitionRequest?.endAudio()
                self.recognitionTask?.cancel()
                self.recognitionTask = nil
                self.recognitionRequest = nil
                self.microphoneButton.isEnabled = false
                
                DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                    if self.temp != " "{
                        self.appendToTextField(string: self.temp)
                        print("messaggio che mando:" + self.temp) }
                })
                DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2), execute: {
                    if self.temp != " "{
                        self.sendAutomatically()
                    }
                    else {
                        sleep(1)
                    }
                })
            })
            //})
            
        }
    }
    
    @IBAction func microphoneTapped(_ sender: Any) {

        if self.timer != nil {
            self.timer?.invalidate()
            self.timer = nil
            self.microphoneButton.isEnabled = false
        } /*else {
            self.timer = Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(SpeechViewController.startSpeech),userInfo: nil, repeats: true)
            //self.microphoneButton.setTitle("Termina", for: .normal)
        }*/
    }
    
    private func sendAutomatically(){
        guard let client = client else { return }
        
        switch client.connect(timeout: 10) {
        case .success:
            
                if let response = sendRequest(string: "CHAT"  + self.temp, using: client){
                    //gestione dato in ricezione
                    print("ho ricevuto: " + response)
                    let correctRes = response.dropFirst(4)
                    print(correctRes)
                    chatMsg.append(String(correctRes))
                    self.chatView.insertRows(at: [IndexPath.init(row:self.chatMsg.count-1, section:0)], with: .automatic)
                    self.temp = " "
                }
                else {
                    print("errore")
                }
            
        case .failure(let error):
            print("errore di connessione al server: " + String(describing: error))
        }
        client.close()
        sleep(1)
    }
    
    
    //METODI DI GESTIONE DELLA SOCKET
    
    private func sendRequest(string: String, using client: TCPClient) -> String? {
        
        switch client.send(string: string) {
        case .success:
            //sleep(10)
            var resp = readResponse(from: client)
            while resp == nil{
                resp = readResponse(from: client)
            }
            return resp
        case .failure(let error):
            print("errore sulla send: " + String(describing: error))
            return nil
        }
    }
    
    private func readResponse(from client: TCPClient) -> String? {
        guard let response = client.read(1024*10) else { return nil }
        return String(bytes: response, encoding: .utf8)
    }
    
    private func appendToTextField(string: String) {
        self.chatMsg.append(string)
        self.chatView.insertRows(at: [IndexPath.init(row:self.chatMsg.count-1, section:0)], with: .automatic)
    }
    
    
    func startRecording() {
        
        if recognitionTask != nil {
            recognitionTask?.cancel()
            recognitionTask = nil
        }
        
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(AVAudioSessionCategoryRecord)
            try audioSession.setMode(AVAudioSessionModeMeasurement)
            try audioSession.setActive(true, with: .notifyOthersOnDeactivation)
        } catch {
            print("audioSession properties weren't set because of an error.")
        }
        
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        /*
         guard let inputNode = audioEngine.inputNode else {
         fatalError("Audio engine has no input node")
         }*/
        let inputNode = audioEngine.inputNode
        
        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create an SFSpeechAudioBufferRecognitionRequest object")
        }
        
        recognitionRequest.shouldReportPartialResults = true
        
        recognitionTask = speechRecognizer!.recognitionTask(with: recognitionRequest, resultHandler: { (result, error) in
            
            var isFinal = false
            var msg : String!
            if result != nil {
                //self.textView.text = result?.bestTranscription.formattedString
                msg = (result?.bestTranscription.formattedString)!
                
                //SALVO I VALORI IN UNA VARIABILE TEMPORANEA MAN MANO CHE VENGONO RICONOSCIUTI
                
                print("Best transcription: " + msg)
                
                self.temp = msg
                isFinal = (result?.isFinal)!
            }
            
            if error != nil || isFinal {
                
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                
                self.recognitionRequest = nil
                self.recognitionTask = nil
                
                //self.microphoneButton.isEnabled = true
            }
        })
        
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
            self.recognitionRequest?.append(buffer)
        }
        
        audioEngine.prepare()
        
        do {
            try audioEngine.start()
        } catch {
            print("audioEngine couldn't start because of an error.")
        }
        
        //textView.text = "Say something, I'm listening!"
        
    }
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if available {
            microphoneButton.isEnabled = true
        } else {
            microphoneButton.isEnabled = false
        }
    }
    
    
    // CODICE PER IL PICKER VIEW
    
    func pickUp(_ textField : UITextField){
        
        // UIPickerView
        self.picker = UIPickerView(frame:CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 216))
        self.picker.delegate = self
        self.picker.dataSource = self
        //self.picker.backgroundColor = UIColor.white
        let keyArr = Array(siriLanAV.keys)
        let index : Int = keyArr.index(of: speechRL)!
        self.picker.selectRow(index, inComponent: 0, animated: true)
        textField.inputView = self.picker
        
        // ToolBar
        let toolBar = UIToolbar()
        toolBar.barStyle = .default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor(red: 92/255, green: 216/255, blue: 255/255, alpha: 1)
        toolBar.sizeToFit()
        
        // Adding Button ToolBar
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(InfoTableViewController.doneClick))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(InfoTableViewController.cancelClick))
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        textField.inputAccessoryView = toolBar
        
    }
    
    //MARK:- PickerView Delegate & DataSource
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return siriLanAV.values.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let key = Array(siriLanAV.keys)[row]
        let value = siriLanAV[key]
        return value
        
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let key = Array(siriLanAV.keys)[row]
        self.speechRL = key
        if siriLanAV[key] == "Italiano"{
            self.siriLabel.text = "La lingua corrente di Siri è"
            self.siriLan.text = siriLanAV[key]
        }
        else if siriLanAV[key] == "English"{
            self.siriLabel.text = "Siri current language is"
            self.siriLan.text = siriLanAV[key]
        }
        else if siriLanAV[key] == "Français"{
            self.siriLabel.text = "La langue actuelle de Siri est"
            self.siriLan.text = siriLanAV[key]
        }
        else if siriLanAV[key] == "Deutsch"{
            self.siriLabel.text = "Die aktuelle sprache von Siri ist"
            self.siriLan.text = siriLanAV[key]
        }
        else if siriLanAV[key] == "Español"{
            self.siriLabel.text = "El lenguaje actual de Siri es"
            self.siriLan.text = siriLanAV[key]
        }
    }
    
    //MARK:- TextFiled Delegate
    func textFieldDidBeginEditing(_ textField: UITextField) {
        self.pickUp(siriLan)
    }
    
    //MARK:- Button
    @objc func doneClick() {
        //hideKeyboardWhenTappedAround()
        self.speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: speechRL))
        siriLan.resignFirstResponder()
    }
    @objc func cancelClick() {
        //hideKeyboardWhenTappedAround()
        siriLan.resignFirstResponder()
    }
    
}

extension UITableView {
    
    func scrollToBottom() {
        let rows = self.numberOfRows(inSection: 0)
        
        let indexPath = IndexPath(row: rows - 1, section: 0)
        self.scrollToRow(at: indexPath, at: .top, animated: true)
    }
}

