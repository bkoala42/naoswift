//
//  SenderTableViewCell.swift
//  LAN Scan
//
//  Created by giovanniiodice on 28/09/2017.
//  Copyright © 2017 Smart Touch. All rights reserved.
//

import UIKit
import Foundation

class SenderTableViewCell: UITableViewCell {
    @IBOutlet weak var texttLabel: UILabel?
    @IBOutlet weak var textView: UITextView!
    
    //@IBOutlet weak var imageField: UIImageView!
    
    /*override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }*/
    
    /*
    override func layoutSubviews() {
        super.layoutSubviews()
        
        /*self.texttLabel?.frame = CGRect(x:15,y:10,width:200,height:30)
        self.texttLabel?.adjustsFontSizeToFitWidth = true
        self.texttLabel?.textColor = UIColor.green
        */
        self.texttLabel?.textAlignment = .right
    }*/
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
