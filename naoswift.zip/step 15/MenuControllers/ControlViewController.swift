//
//  ControlViewController.swift
//  LAN Scan
//
//  Created by giovanniiodice on 28/09/2017.
//  Copyright © 2017 Smart Touch. All rights reserved.
//
import UIKit
import Foundation
import QuartzCore
import CoreMotion
import SwiftSocket


class ControlViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var sliderAI: UISlider!
    @IBOutlet weak var sliderDS: UISlider!
    @IBOutlet weak var labelDS: UILabel!
    @IBOutlet weak var labelAI: UILabel!
    @IBOutlet weak var sayTextField: UITextField!
    var client : TCPClient?
    
    var thresholdDS = 30
    var thresholdAI = 20
    var buttonIsStart = false
    let motionManager = CMMotionManager()
    var condition : Bool?
    var stringToSay : String = ""
    
    func degrees(_ radians:Double) -> Double {
        return 180 / Double.pi * radians
    }
    
    //MANCANO LE ACTION DEI BTN POSIZIONI -> MOVE{Crouch, Sit, SitRelax, LyingBelly, LyingBack,
    //Stand, StandInit, StandZero}
    //ACTION BTN turnLeft turnRight -> MOVEturnLeft MOVEturnRight
    //RETURN SULLA TASTIERA quando si preme return manda msg
    //TEXTBOX -> DOITsay{textbox.text}
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set connessione
        client = TCPClient(address: ipAddress, port: 7783)
        
        sliderAI.maximumValue = 90
        sliderAI.minimumValue = 10
        sliderDS.maximumValue = 90
        sliderDS.minimumValue = 10
        
        sliderAI.setValue(20, animated: true)
        labelAI.text = sliderAI.value.description
        
        sliderDS.setValue(30, animated: true)
        labelDS.text = sliderDS.value.description
        
        //button.layer.cornerRadius = 35
        button.layer.backgroundColor = UIColor.green.cgColor
        button.setTitle("START", for: .normal)
        // Do any additional setup after loading the view.
        self.sayTextField.delegate = self
        hideKeyboardWhenTappedAroundPers()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if ipAddress != ""{
            self.client = TCPClient(address: ipAddress, port: 7783)
        }
    }
    
    func stopDataUpdate( ) {
        motionManager.stopDeviceMotionUpdates()
    }
    
    
    func startDataUpdate() {
        self.condition = true
        if motionManager.isDeviceMotionAvailable {
            _ = motionManager.deviceMotion
            motionManager.startDeviceMotionUpdates(
                to: OperationQueue.current!, withHandler: {
                    (deviceMotion, error) -> Void in
                    
                    if(error == nil) {
                        self.handleDeviceMotionUpdate(deviceMotion: deviceMotion!)
                    } else {
                        //handle the error
                    }
            })
            motionManager.deviceMotionUpdateInterval = 1
            
        }
    }
    
    func handleDeviceMotionUpdate(deviceMotion:CMDeviceMotion) {
        let attitude = deviceMotion.attitude
        let roll = degrees(attitude.roll)
        let pitch = degrees(attitude.pitch)
        _ = degrees(attitude.yaw) // inutile è l'asse z
        //print("Roll: \(roll), Pitch: \(pitch), Yaw: \(yaw)")
        
        if (pitch > Double(thresholdAI)){
            print("Vai indietro.")
            //MANDA MOVEbackward
            if self.condition! {
                self.setCommand(_string: "MOVEbackward")
                //sleep(3)
                self.condition = false
            } else {
                self.setCommand(_string: "MOVEbackward")
            }
        }
        if (pitch < -Double(thresholdAI)){
            print("Vai avanti.")
            //MANDA MOVEforward
            if self.condition! {
                self.setCommand(_string: "MOVEforward")
                //sleep(3)
                self.condition = false
            } else {
                self.setCommand(_string: "MOVEforward")
            }
        }
        if(roll > Double(thresholdDS)){
            print("Vai a destra.")
            //MANDA MOVEright
            if self.condition! {
                self.setCommand(_string: "MOVEright")
                //sleep(3)
                self.condition = false
            } else {
                self.setCommand(_string: "MOVEright")
            }
        }
        if(roll < -Double(thresholdDS)){
            print("Vai a sinistra.")
            //MANDA MOVEleft
            if self.condition! {
                self.setCommand(_string: "MOVEleft")
                //sleep(3)
                self.condition = false
            } else {
                self.setCommand(_string: "MOVEleft")
            }
        }
        //quando devi mandare i msg al server considera i tempi d'esecuzione.
        //aspetta 3 secondi per il primo comando e rinvia dopo 1 solo secondo inmodo da farlo restare in posizione cammina
        //settato il tempo di refresh dei dati a 1 secondo
        //fai in modo di inviare un solo messaggio direzione. se inclini il cell in diagonale fa due stampe!!!!
    }
    
    
    @IBAction func buttonPressed(_ sender: UIButton) {
        if buttonIsStart {
            //stop the service
            buttonIsStart = false
            button.layer.backgroundColor = UIColor.green.cgColor
            button.setTitle("START", for: .normal)
            stopDataUpdate()
        }
        else {
            //start service
            buttonIsStart = true
            button.layer.backgroundColor = UIColor.red.cgColor
            button.setTitle("STOP", for: .normal)
            startDataUpdate()
        }
    }
    @IBAction func sliderDSChange(_ sender: UISlider) {
        labelDS.text = String(sliderDS.value)
        thresholdDS = Int(sliderDS.value)
    }
    
    @IBAction func sliderAIChange(_ sender: UISlider) {
        labelAI.text = String(sliderAI.value)
        thresholdAI = Int(sliderAI.value)
    }
    
    
    // CODICE PER SOCKET
    // METODI PER MANDARE E RICEVERE DATI TRAMITE SOCKET
    
    private func readResponse(from client: TCPClient) -> String? {
        guard let response = client.read(1024*10) else { return nil }
        return String(bytes: response, encoding: .utf8)
    }
    
    
    private func sendRequest(string: String, using client: TCPClient) -> String? {
        switch client.send(string: string) {
        case .success:
            var resp = readResponse(from: client)
            while resp == nil{
                resp = readResponse(from: client)
            }
            return resp
        case .failure(let error):
            print(String(describing: error))
            return nil
        }
    }
    
    private func setCommand(_string : String){
        guard let client = client else { return }
        
        switch client.connect(timeout: 10) {
        case .success:
            //SEND RICHIESTA
            if let response = sendRequest(string: _string, using: client){
                //gestione dato in ricezione
                print("ho ricevuto: " + response)
            }else{
                print("errore")
            }
        case .failure(let error):
            print("errore di connessione al server: " + String(describing: error))
        }
        client.close()
    }
    
}

// METODI DEI BOTTONI
extension ControlViewController {
    @IBAction func standButton(_ sender: UIButton) {
        self.setCommand(_string: "PSTNStand")
    }
    @IBAction func standInitButton(_ sender: UIButton) {
        self.setCommand(_string: "PSTNStandInit")
    }
    @IBAction func standZeroButton(_ sender: UIButton) {
        self.setCommand(_string: "PSTNStandZero")
    }
    @IBAction func sitButton(_ sender: UIButton) {
        self.setCommand(_string: "PSTNSit")
    }
    @IBAction func relaxButton(_ sender: UIButton) {
        self.setCommand(_string: "PSTNSitRelax")
    }
    @IBAction func bellyButton(_ sender: UIButton) {
        self.setCommand(_string: "PSTNLyingBelly")
    }
    @IBAction func backButton(_ sender: UIButton) {
        self.setCommand(_string: "PSTNLyingBack")
    }
    @IBAction func crouchButton(_ sender: UIButton) {
        self.setCommand(_string: "PSTNCrouch")
    }
    @IBAction func turnLeftButton(_ sender: UIButton) {
        self.setCommand(_string: "MOVEturnLeft")
    }
    @IBAction func turnRightButton(_ sender: UIButton) {
        self.setCommand(_string: "MOVEturnRight")
    }
    
    //TextField Delegate
     func textFieldDidBeginEditing(_ textField: UITextField) {
        self.stringToSay = textField.text!
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.stringToSay = textField.text!
    }
    
    
    func hideKeyboardWhenTappedAroundPers() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ControlViewController.dismissKeyboardd))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    @objc func dismissKeyboardd() {
        view.endEditing(true)
        self.sayTextField.text = ""
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        dismissKeyboardd()
        setCommand(_string: "DOITsay" + self.stringToSay)
        return true
    }
    
}
