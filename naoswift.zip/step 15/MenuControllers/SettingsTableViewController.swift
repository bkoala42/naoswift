//
//  SettingsTableViewController.swift
//  LAN Scan
//
//  Created by giovanniiodice on 29/09/2017.
//  Copyright © 2017 Smart Touch. All rights reserved.
//

import UIKit
import SwiftSocket


//SET DI UNA VARIABILE GLOBALE CONDIVISA TRA TUTTI I CONTROLLER
var ipAddress: String=""
var dialSet : String = ""

class SettingsTableViewController: UITableViewController {

    @IBOutlet weak var detailWiFi: UILabel!
    @IBOutlet weak var dialogueLabel: UILabel!
    @IBOutlet weak var dialogueTitle: UILabel!
    @IBOutlet weak var tablleView: UITableView!
    
    var picker : UIPickerView!
    var client: TCPClient?
    var dialAvailable : [String]!
    var dialCurrent : String!
    var ipPrevious : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        hideKeyboardWhenTappedAround()
        self.dialogueTitle.text = dialSet
        self.detailWiFi.text = ipAddress
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if ipPrevious == ipAddress{
            detailWiFi.text = ipAddress
            self.dialogueTitle.text = dialSet
        }
        else {
            detailWiFi.text = ipAddress
            self.dialogueTitle.text = ""
            self.ipPrevious = ipAddress
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if section == 0{
            return 2
        }
        else if section == 1 {
            return 1
        }
        return 1
    }

    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */
    /*
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (tableView.cellForRow(at: indexPath)?.description == "dialogue" && ipAddress == ""){
            performSegue(withIdentifier: "whoops", sender: nil)
        }
    }*/
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if (segue.identifier == "info" && ipAddress == ""){
            performSegue(withIdentifier: "whoops", sender: nil)
        }
        if (segue.identifier == "address"){
            self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
        }
        /*if (segue.identifier == "dialogue" && ipAddress != ""){
            if let navVC = segue.destination as? UINavigationController{
                if let vc = navVC.viewControllers[0] as? DialoguesTableViewController{
                    vc.dialogues = self.dialAvailable
                }
            }
        }*/
    }
}
    
   

extension SettingsTableViewController {
    
    @IBAction func cancelToSettingsViewController(_ segue: UIStoryboardSegue) {
        DispatchQueue.main.async{
            self.tablleView.reloadData()
        }
    }
    
    @IBAction func saveWiFiDetail(_ segue: UIStoryboardSegue) {
        DispatchQueue.main.async{
            self.tablleView.reloadData()
        }
    }
    
}

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}
