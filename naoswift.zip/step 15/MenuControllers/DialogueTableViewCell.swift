//
//  DialogueTableViewCell.swift
//  LAN Scan
//
//  Created by giovanniiodice on 01/10/2017.
//  Copyright © 2017 Smart Touch. All rights reserved.
//

import UIKit

class DialogueTableViewCell: UITableViewCell {
    @IBOutlet weak var dialogLabel: UILabel!
    @IBOutlet weak var dialogDetail: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
