//
//  DialoguesTableViewController.swift
//  LAN Scan
//
//  Created by giovanniiodice on 01/10/2017.
//  Copyright © 2017 Smart Touch. All rights reserved.
//

import UIKit
import SwiftSocket

class DialoguesTableViewController: UITableViewController {

    var dialogues = [String]()
    var dialog = [String]()
    var dialToSet : String!
    var client : TCPClient?
    
    @IBOutlet var dialTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // set connessione
        client = TCPClient(address: ipAddress, port: 7783)
        self.dialTableView.rowHeight = 45
        //self.getCurrentDialogues()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if ipAddress != ""{
            self.client = TCPClient(address: ipAddress, port: 7783)
            self.getCurrentDialogues()
            self.dialTableView.reloadData()
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        NotificationCenter.default.addObserver(forName: .UIContentSizeCategoryDidChange, object: .none, queue: OperationQueue.main) { [weak self] _ in
            self?.dialTableView.reloadData()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return dialog.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "dcell", for: indexPath) as! DialogueTableViewCell
        
        // Configure the cell...
        
        //if String(Array(dialog[indexPath.row].characters)[...6]) == "italian"{
        
        cell.dialogLabel.text = String(Array(dialog[indexPath.row].characters)[8...])
        cell.dialogDetail.text = String(Array(dialog[indexPath.row].characters)[...6])

        //}
        /*else if String(Array(dialog[indexPath.row].characters)[...6]) == "english"{
            cell.dialogLabel.text = String(Array(dialog[indexPath.row].characters)[7...])
            cell.dialogDetail.text = String(Array(dialog[indexPath.row].characters)[...5])
        }*/
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cc = tableView.cellForRow(at: indexPath) as! DialogueTableViewCell
        let newPath : String = "/home/nao/application/dialog/" + cc.dialogDetail.text! + "/" + cc.dialogLabel.text!
        self.dialToSet = newPath
        
        dialSet = cc.dialogLabel.text!
        
        //performSegue(withIdentifier: "done", sender: nil)
    }

    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if (identifier ==  "done") {
            if (dialToSet != nil){
            setDialogue(_string: dialToSet)
                return true
            }
            let alert = UIAlertController(title: "Prof", message: "il dialogo!!!", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
                //print("Handle Ok logic here")
            }))
            present(alert, animated: true, completion: nil)
            return false
        }
        return true
    }

    
    
    // CODICE PER SOCKET
    // METODI PER MANDARE E RICEVERE DATI TRAMITE SOCKET
    
    private func readResponse(from client: TCPClient) -> String? {
        guard let response = client.read(1024*10) else { return nil }
        return String(bytes: response, encoding: .utf8)
    }
    
    
    private func sendRequest(string: String, using client: TCPClient) -> String? {
        switch client.send(string: string) {
        case .success:
            var resp = readResponse(from: client)
            while resp == nil{
                resp = readResponse(from: client)
            }
            return resp
        case .failure(let error):
            print("errore nella risposta" + String(describing: error))
            return nil
        }
    }
    
    
    
    // CODICE PER INIZIALIZZARE LA LABEL DEL TOPIC DEL DIALOGO
    func getCurrentDialogues() {
        guard let client = self.client else{ return }
        
        switch client.connect(timeout: 10) {
        case .success:
            if let response = sendRequest(string: "CHDIreturnList", using: client){
                //gestione dato in ricezione
                print("ho ricevuto: " + response)
                let correctRes = response.dropFirst(4)
                print(correctRes)
                self.dialogues = correctRes.components(separatedBy: " ")
                print(dialogues)
                
                _ = dialogues.removeLast()
                
                //pulizia array
                for path in dialogues {
                    if String(Array(path.characters)[...28]) == "/home/nao/application/dialog/"{
                        self.dialog.append(String(Array(path.characters)[29...]))
                    }
                }
                print(dialog)
            }else{
                print("errore")
            }
        case .failure(let error):
            print("errore di connessione al server: " + String(describing: error))
            print(error.localizedDescription)
            //performSegue(withIdentifier: "whoops", sender: nil)
        }
        client.close()
    }
    

    // METODO PER SETTARE IL FILE DI DIALOGO
    func setDialogue(_string: String){
        guard let client = client else { return }
        
        switch client.connect(timeout: 10) {
        case .success:
            //SEND RICHIESTA
            if let response = sendRequest(string: "CHDI" + _string, using: client){
                //gestione dato in ricezione
                print("ho ricevuto: " + response)
            }else{
                print("errore")
            }
            
        case .failure(let error):
            print("errore di connessione al server: " + String(describing: error))
        }
        client.close()
    }
    
}
