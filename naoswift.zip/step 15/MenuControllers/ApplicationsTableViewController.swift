//
//  ApplicationsTableViewController.swift
//  LAN Scan
//
//  Created by giovanniiodice on 02/10/2017.
//  Copyright © 2017 Smart Touch. All rights reserved.
//

import UIKit
import SwiftSocket

class ApplicationsTableViewController: UITableViewController {

    @IBOutlet var appTableView: UITableView!
    
    var applications = [String]()
    var appToSet : String!
    var client : TCPClient?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set connessione
        client = TCPClient(address: ipAddress, port: 7783)
        self.appTableView.rowHeight = 55
        if (ipAddress == ""){
            performSegue(withIdentifier: "whoops", sender: nil)
        }
        self.getApplications()
        hideKeyboardWhenTappedAround()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if ipAddress != ""{
            self.client = TCPClient(address: ipAddress, port: 7783)
            self.getApplications()
            
            for index in 1...applications.count {
                let cell = appTableView.cellForRow(at: IndexPath(row: index, section: 0))
                cell?.accessoryType = .none
            }
        } else {
            performSegue(withIdentifier: "whoops", sender: nil)
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        NotificationCenter.default.addObserver(forName: .UIContentSizeCategoryDidChange, object: .none, queue: OperationQueue.main) { [weak self] _ in
            self?.appTableView.reloadData()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return applications.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "acell", for: indexPath) as! ApplicationsTableViewCell
        // Configure the cell...
        cell.appLabel.text = applications[indexPath.row]
        return cell
    }
 
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cc = tableView.cellForRow(at: indexPath) as! ApplicationsTableViewCell
        cc.setSelected(false, animated: true)
        self.appToSet = cc.appLabel.text
        cc.accessoryType = .checkmark
    }
    override func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        let cc = tableView.cellForRow(at: indexPath) as! ApplicationsTableViewCell
        cc.accessoryType = .none
    }

    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        if (identifier ==  "done") {
            if appToSet != nil {
                setApplication(_string: appToSet)
                
                for index in 1...applications.count {
                    let cell = appTableView.cellForRow(at: IndexPath(row: index, section: 0))
                    cell?.accessoryType = .none
                }
            }
            return false
        }
        if (identifier == "cancel") {
            setApplication(_string: "stop")
            for index in 1...applications.count {
                let cell = appTableView.cellForRow(at: IndexPath(row: index, section: 0))
                cell?.accessoryType = .none
            }
        }
        return true
        
    }
    
    // METODO PER SETTARE LE CELLE DELLA TABLE VIEW
    // CODICE PER INIZIALIZZARE LA LABEL DEL TOPIC DEL DIALOGO
    
    func getApplications(){
        guard let client = self.client else{ return }
        
        switch client.connect(timeout: 10) {
        case .success:
            if let response = sendRequest(string: "APPLreturnList", using: client){
                //gestione dato in ricezione
                print("ho ricevuto: " + response)
                let correctRes = response.dropFirst(4)
                print(correctRes)
                self.applications = correctRes.components(separatedBy: " ")
                print(applications)
                
            }else{
                print("errore")
            }
        case .failure(let error):
            print("errore di connessione al server: " + String(describing: error))
            performSegue(withIdentifier: "whoops", sender: nil)
        }
        client.close()
    }
    
    // CODICE PER SOCKET
    // METODI PER MANDARE E RICEVERE DATI TRAMITE SOCKET
    
    private func readResponse(from client: TCPClient) -> String? {
        guard let response = client.read(1024*10) else { return nil }
        return String(bytes: response, encoding: .utf8)
    }
    
    private func sendRequest(string: String, using client: TCPClient) -> String? {
        switch client.send(string: string) {
        case .success:
            //sleep(10)
            var resp = readResponse(from: client)
            while resp == nil{
                resp = readResponse(from: client)
            }
            return resp
        case .failure(let error):
            print(String(describing: error))
            return nil
        }
    }
    
    // METODO PER SETTARE IL FILE DI DIALOGO
    func setApplication(_string: String){
        guard let client = client else { return }
        
        switch client.connect(timeout: 10) {
        case .success:
            //SEND RICHIESTA
            if let response = sendRequest(string: "APPL" + _string, using: client){
                //gestione dato in ricezione
                print("ho ricevuto: " + response)
            }else{
                print("errore")
            }
            
        case .failure(let error):
            print("errore di connessione al server: " + String(describing: error))
        }
        client.close()
    }

}
