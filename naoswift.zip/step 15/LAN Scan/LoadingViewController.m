//
//  LoadingViewController.m
//  LAN Scan
//
//  Created by giovanniiodice on 25/09/2017.
//  Copyright © 2017 Smart Touch. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LoadingViewController.h"
#import "LAN_Scan-Swift.h"
#import "SWRevealViewController.h"

@interface  LoadingViewController()
@property (weak, nonatomic) IBOutlet UIBarButtonItem *menuButton;
@end

@implementation LoadingViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    if (self.revealViewController != nil){
        _menuButton.target = self.revealViewController;
        _menuButton.action = @selector(revealToggle:);
        //self.view.userInteractionEnabled = YES;
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    
}

- (IBAction)automaticSearch:(UIButton *)sender {
    //prepare for segue
}
- (IBAction)manualSearch:(UIButton *)sender {
    //prepare for segue
}



- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([segue.identifier isEqualToString:@"manual"]) {
        //manda il dato inserito al prossimo controller
        //SwiftViewController *vc = (SwiftViewController *)segue.destinationViewController;
        //InfoViewController *vc = (InfoViewController *)segue.destinationViewController;
        
        //collego al navigation controller
        //UINavigationController *destNC = (UINavigationController*)segue.destinationViewController;
        //InfoTableViewController *tc =(InfoTableViewController *)destNC.topViewController;
        
        if ([_textField.text  isEqual: @""]){
            UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Empty Field"
                                                                           message:@"Please set a valid ip address"
                                                                    preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                                  handler:^(UIAlertAction * action) {}];
            
            [alert addAction:defaultAction];
            [self presentViewController:alert animated:YES completion:nil];
        }
        else {
            //vc.textstr = _textField.text;
            //tc.textstr = _textField.text;
        }
        
        
        
        
    }
    else if ([segue.identifier isEqualToString:@"automatic"]) {
        //solo load della segue
    }
}

//NON FUNZIONA
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    int groupingSize = 2;
    if([string length] == 0) {
        groupingSize = 4;
    }
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init] ;
    NSString *separator = @".";
    [formatter setGroupingSeparator:separator];
    [formatter setGroupingSize:groupingSize];
    [formatter setUsesGroupingSeparator:YES];
    [formatter setSecondaryGroupingSize:2];
    if (![string  isEqual: @""] && (textField.text != nil && textField.text.length > 0)) {
        NSString *num = textField.text;
        num = [num stringByReplacingOccurrencesOfString:separator withString:@""];
        NSString *str = [formatter stringFromNumber:[NSNumber numberWithDouble:[num doubleValue]]];
        textField.text = str;
    }
    return YES;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    if(![touch.view isMemberOfClass:[UITextField class]]) {
        [touch.view endEditing:YES];
    }
}

@end
