//
//  ViewController.h
//  LAN Scan
//
//  Created by Mongi Zaidi on 24 February 2014.
//  Copyright (c) 2014 Smart Touch. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ScanLAN.h"

@class SwiftViewController;
@interface ViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, ScanLANDelegate>
@property (nonatomic, strong) NSString *myString;
@end

