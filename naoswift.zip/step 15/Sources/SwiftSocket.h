@import Foundation;

//! Project version number for SwiftSocket
FOUNDATION_EXPORT double SwiftSocketVersionNumber;

//! Project version string for SwiftSocket
FOUNDATION_EXPORT const unsigned char SwiftSocketVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftSocket_iOS/PublicHeader.h>
