LAN-Scan
========

An iOS Local Area Network / wifi Scanner

![](https://raw.github.com/mongizaidi/LAN-Scan/master/LAN%20Scan/screenshot.png)
